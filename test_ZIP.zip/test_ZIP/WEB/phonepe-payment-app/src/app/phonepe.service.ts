import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import * as CryptoJS from 'crypto-js'; // Import CryptoJS for hash calculation

@Injectable({
  providedIn: 'root'
})
export class PhonepeService {
  private apiUrl = 'https://api-preprod.phonepe.com/apis/pg-sandbox/pg/v1/pay'; // Testing URL
  private apiKey = '099eb0cd-02cf-4e2a-8aca-3e6c6aff0399'; // Replace with your API key
  private keyIndex = 1; // Replace with your key index

  constructor(private http: HttpClient) { }

  makePhonePePayment(): Observable<any> {
    const merchantId = 'MERCHANTUAT'; // Replace with your merchant ID
    const merchantTransactionId = (Math.floor(Math.random() * (999999 - 111111 + 1)) + 111111).toString();
    const merchantUserId = `MUID${Date.now()}`;
    const amount = 1 * 100; // Amount in cents
    const redirectUrl = 'https://kumudu.in';
    const redirectMode = 'POST'; // or 'GET'
    const mobileNumber = '9999999999';
    const paymentInstrumentType = 'PAY_PAGE';

    const requestData = {
      merchantId,
      merchantTransactionId,
      merchantUserId,
      amount,
      redirectUrl,
      redirectMode,
      mobileNumber,
      paymentInstrument: {
        type: paymentInstrumentType,
      },
    };

    const encodedData = btoa(JSON.stringify(requestData)); // Use btoa for base64 encoding
    const stringToHash = `${encodedData}/pg/v1/pay${this.apiKey}`;
    const sha256 = CryptoJS.SHA256(stringToHash).toString(CryptoJS.enc.Hex); // Calculate SHA-256 hash

    const finalXHeader = `${sha256}###${this.keyIndex}`;

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      accept: 'application/json',
      'X-VERIFY': finalXHeader,
    });

    return this.http.post<any>(this.apiUrl, { request: encodedData }, { headers });
  }
}

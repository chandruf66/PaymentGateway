import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PhonepePaymentComponent } from './phonepe-payment.component';

describe('PhonepePaymentComponent', () => {
  let component: PhonepePaymentComponent;
  let fixture: ComponentFixture<PhonepePaymentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PhonepePaymentComponent]
    });
    fixture = TestBed.createComponent(PhonepePaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { PhonepeService } from '../phonepe.service'; // Import the PhonepeService
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router'; // Import Router

@Component({
  selector: 'app-phonepe-payment',
  templateUrl: './phonepe-payment.component.html',
  styleUrls: ['./phonepe-payment.component.css']
})
export class PhonepePaymentComponent implements OnInit {
  redirectUrl: string = ''; 
  router: any;
  constructor(private phonepeService: PhonepeService,private http: HttpClient) {} // Inject the PhonepeService
 

  ngOnInit(): void {}

  initiatePhonePePayment() {
    // this.phonepeService.makePhonePePayment().subscribe(
    //   (response) => {
    //     const redirectUrl = response.data.instrumentResponse.redirectInfo.url;
    //     console.log('Redirect URL:', redirectUrl);

    //     // Redirect the user to the PhonePe payment page
    //     window.location.href = redirectUrl;
    //   },
    //   (error) => {
    //     if (error.status) {
    //       console.error('Error Status:', error.status);
    //       console.error('Error Data:', error.error);
    //     } else {
    //       console.error('Error:', error.message);
    //     }
    //   }
    // );

    this.http.post('http://localhost:3000/phonepe-payment', {}).subscribe(
      (response: any) => {
        console.log('Payment initiation response:', response);
        this.redirectUrl = response.redirectUrl;
        window.location.href = this.redirectUrl;
        // Handle the response here
        // You can access the response data using 'response' variable
      },
      (error: any) => {
        console.error('Error sending payment initiation request:', error);
        // Handle error as needed
      }
    );

    


  }
}

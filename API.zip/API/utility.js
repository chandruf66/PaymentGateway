const utility = {
  rupeesToPaise: function (rupees) {
    return rupees * 100;
  },
  paiseToRupees: function (paise) {
    return paise / 100;
  },
};

module.exports = utility;

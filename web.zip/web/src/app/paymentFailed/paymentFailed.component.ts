import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentFailed',
  templateUrl: './paymentFailed.component.html',
  styleUrls: ['./paymentFailed.component.css']
})
export class PaymentFailedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

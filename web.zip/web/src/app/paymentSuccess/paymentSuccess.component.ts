import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentSuccess',
  templateUrl: './paymentSuccess.component.html',
  styleUrls: ['./paymentSuccess.component.css']
})
export class PaymentSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
